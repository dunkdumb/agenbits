# Core module init
